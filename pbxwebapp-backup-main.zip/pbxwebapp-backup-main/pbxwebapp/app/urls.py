from django.urls import path

from .views import *

urlpatterns = [
    path('', view=home, name='home'),
    path('getcommandoutput/<str:command>/', view=getCommandOutput),

    path('accounts/login/', loginView, name='login'),
    path('accounts/logout/', logoutView, name='logout'),



]