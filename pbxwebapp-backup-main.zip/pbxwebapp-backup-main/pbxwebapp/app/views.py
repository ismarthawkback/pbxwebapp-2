from django.shortcuts import render, redirect
from django.http import JsonResponse
import time
# Create your views here.

from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.views.decorators.cache import cache_control

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def loginView(request) :
    if request.method == 'POST' :
        username = request.POST['username']
        password = request.POST['password']
        print(username, password)
        user = authenticate(request, username=username, password=password)
        if user :
            login(request, user)
            return redirect('/')
        else :
            messages.error(request, 'Invalid username or password.')
    user = request.user
    if user.username : return redirect('/')
    return render(request, 'app/login.html')


def logoutView(request) :
    logout(request)
    return redirect('/')

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def home(request) :
    user = request.user
    if user.username == '' :
        return redirect('accounts/login/')
    # print(user, type(user), user.username, type(user.username))

    context = {
        'commands' : {
            'Channels' : ['core show channel 1', 'core show channel 2'],
            'Calls' : ['core show calls', 'core show calls 2']
        },
        'user' : user,
    }
    return render(request, 'app/partials/status.html', context)


def getCommandOutput(request, command) :
    print(command)
    time.sleep(2)
    return JsonResponse({
        'command' : '$ ' + command,
        'message' : 'Output for ' + command,
    })
