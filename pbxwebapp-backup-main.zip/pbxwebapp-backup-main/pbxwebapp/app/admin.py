from django.contrib import admin

from .models import *



# not required
admin.site.register(AstConfbridge)
admin.site.register(AstAccbar)
admin.site.register(AstAccbar1)
admin.site.register(AstCdr)
admin.site.register(AstFollowme)
admin.site.register(AstFollowmeNumbers)
admin.site.register(AstSipcontacts)
admin.site.register(AstSipfriends)
admin.site.register(AstVoicemailUsers)
admin.site.register(HomeAstSipfriends)
admin.site.register(VoicemailMessages)
admin.site.register(VoicemailUsers)
